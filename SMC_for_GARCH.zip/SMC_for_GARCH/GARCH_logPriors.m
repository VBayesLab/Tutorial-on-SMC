function out = GARCH_logPriors(w,psi_1,psi_2,prior)
% LOGPRIORS calculate log of priors for GARCH

%out  =  log_invgampdf(w,prior.w_alpha,prior.w_beta)+log(betapdf(alpha,prior.alpha_a,prior.alpha_b))...
%          +log(betapdf(beta,prior.beta_a,prior.beta_b));
out  =  log_invgampdf(w,prior.w_alpha,prior.w_beta);
end

