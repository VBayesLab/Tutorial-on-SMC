function [llh,sigma2_new] = GARCH_llh_conditional(y_new,y_pre,sigma2_pre,w,alpha,beta)
% Calculate log-likelihood of p(y_t+1 | y_1:t, theta)

sigma2_new = w+alpha.*sigma2_pre+beta.*y_pre^2;
    
llh = -0.5*log(2*pi) - 0.5*log(sigma2_new) - 0.5*(y_new^2)./sigma2_new;

end

