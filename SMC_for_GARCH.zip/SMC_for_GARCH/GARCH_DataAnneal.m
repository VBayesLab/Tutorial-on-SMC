function Post = GARCH_DataAnneal(y_all,mdl)
% Implement SMC- data annealing for GARCH
%   y_all           : full dataset including both training and testing data          
%   mdl             : includes all necessary settings, including posterior
%                     approximation from SMC likelihhood annealing with
%                     y_train data
%
% @ Written by Minh-Ngoc Tran (minh-ngoc.tran@sydney.edu.au)


%% Training
M      = mdl.M;             % Number of particles
K      = mdl.K_data;        % Number of Markov moves
prior  = mdl.prior;         % prior setting
T      = mdl.T;             % training data size
sigma0 = mdl.sigma0;        % initial volatility

y_train = y_all(1:T);
y_test  = y_all(T+1:end);
T_test  = length(y_test);

% Forecast score metrics
score.violate = 0;    % Number of times y true is outside forecast interval  
score.crps    = 0;    % Predictve score
score.pps     = 0;    % PPS score
score.qs      = 0;    % Quantile Score
score.hit     = 0;    % Percentage of y instances below forecast VaR
score.alpha   = 0.01; % for forecast interval

% Get equally-weighted particles from SMC lik annealing as the initial particles 
psi_1               = mdl.lik_anneal.psi_1;
psi_2               = mdl.lik_anneal.psi_2;
alpha               = mdl.lik_anneal.alpha;
beta                = mdl.lik_anneal.beta;
w                   = mdl.lik_anneal.w;
theta_particles     = [w,psi_1,psi_2];
W                   = ones(M,1)./M;         % Initialize equal weights for articles in the first level
n_params = 3;                    % Number of parameters

% Run GARCH on training data to get initialization on test data
llh_calc   = zeros(M,1);         % log-likelihood p(y_1:t|theta)
sigma2_cur = zeros(M,1);         % Store conditional variance of the current distribution
for i = 1:M
    [llh_calc(i),sigma2_cur(i)] = GARCH_llh(y_train,sigma0,alpha(i),beta(i),w(i));
end

markov_idx = 0;
annealing_start = tic;
volatility_forecast = zeros(1,T_test);
for t = 0:T_test-1

    %% 1-step-ahead volatility forecast %%
    if t>0 % get current data point y_cur
        y_cur = y_test(t);  
    else
        y_cur = y_train(T);
    end
    sigma2_forecast = one_step_forecast(y_cur,sigma2_cur,w,alpha,beta);
    volatility_forecast(t+1) = W'*sigma2_forecast; % take the weighted mean as the point forecast
    score = one_step_forecast_score(volatility_forecast(t+1),y_test(t+1),score);
    
    %% Re-weighting %%
    % Calculate log conditional likelihood p(y_t+1|y_1:t,theta)
    if t==0
        [llh_condtional,sigma2_cur] = GARCH_llh_conditional(y_test(t+1),y_train(T),sigma2_cur,w,alpha,beta);
    else
        [llh_condtional,sigma2_cur] = GARCH_llh_conditional(y_test(t+1),y_test(t),sigma2_cur,w,alpha,beta);
    end    
    % Update the log likelihood p(y_{1:t+1})
    llh_calc = llh_calc + llh_condtional;
    % Reweighting the particles  
    incw = log(W) + llh_condtional;
    max_incw = max(incw);
    weight   = exp(incw - max_incw);    % Numerical stabability
    W        = weight./sum(weight);               % Calculate weights for current level
    ESS      = 1/sum(W.^2);             % Estimate ESS for particles in the current level
     
        
    %% If the current particles are not good, run resampling and Markov move
    if (ESS < 0.80*M)
        % calculate the covariance matrix to be used in the Random Walk MH
        % proposal. It is better to estimate this matrix BEFORE resampling
        est = sum(theta_particles.*(W*ones(1,n_params)));
        aux = theta_particles - ones(M,1)*est;
        V = aux'*diag(W)*aux;    

        % Resampling for particles at the current annealing level
        indx            = utils_rs_multinomial(W');
        indx            = indx';
        theta_particles = theta_particles(indx,:);
        w               = theta_particles(:,1);
        psi_1           = theta_particles(:,2);
        psi_2           = theta_particles(:,3);
        llh_calc        = llh_calc(indx);
        sigma2_cur      = sigma2_cur(indx);
        W = ones(M,1)./M; % reset weights after resampling 

        % Running Markov move (MH) for each paticles
        markov_start = tic;
        markov_idx = markov_idx + 1;
        accept = zeros(M,1);
        log_prior    = GARCH_logPriors(w,psi_1,psi_2,prior);
        post         = log_prior+llh_calc;
     
        parfor i = 1:M
            iter = 1;
            while iter<=K
                 theta = theta_particles(i,:);
                 % Using multivariate normal distribution as proposal function
                 theta_star = mvnrnd(theta,2.38/n_params*V);
                 w_star = theta_star(1);
                 psi_1_star = theta_star(2);
                 psi_2_star = theta_star(3);
                 alpha_star = psi_1_star*(1-psi_2_star); 
                 beta_star = psi_1_star*psi_2_star; 
                 if (w_star<=0)||(psi_1_star<=0)||(psi_1_star>1)||(psi_2_star<=0)||(psi_2_star>1)
                     acceptance_pro = 0; % acceptance probability is zero --> do nothing
                 else                 
                     % Calculate log-posterior for proposal samples
                     log_prior_star = GARCH_logPriors(w_star,psi_1_star,psi_2_star,prior);             
                     lik_star       = GARCH_llh(y_all(1:T+t+1),sigma0,alpha_star,beta_star,w_star);                                    
                     post_star      = log_prior_star + lik_star;
                     acceptance_pro = exp(post_star-post(i));
                     acceptance_pro = min(1,acceptance_pro);                       
                     if (rand <= acceptance_pro) % if accept the new proposal sample
                         theta_particles(i,:) = theta_star;                     
                         post(i)   = post_star;
                         llh_calc(i)    = lik_star;
                         accept(i) = accept(i) + 1;
                     end
                 end  
                 iter = iter + 1;
            end             
         end
         Post.cpu_move(markov_idx) = toc(markov_start);
         Post.accept_store(:,markov_idx) = accept;
         disp(['Markov move time ',num2str(markov_idx),': ',num2str(Post.cpu_move(markov_idx)),'s'])
    end
    
end

cpu = toc(annealing_start);
w             = theta_particles(:,1);
psi_1         = theta_particles(:,2);
psi_2         = theta_particles(:,3);
Post.w        = w;
Post.alpha    = psi_1.*(1-psi_2);
Post.beta     = psi_1.*psi_2;
Post.psi_1    = psi_1;
Post.psi_2    = psi_2;
Post.cpu      = cpu;
Post.M        = M;              
Post.K        = K;               
Post.W = W;

Post.volatility_forecast = volatility_forecast;
PPS            = score.pps/T_test;   
Violate        = score.violate;
Quantile_Score = score.qs/T_test;    
Hit_Percentage = score.hit/T_test;
Model = {'GARCH'};
results = table(Model,PPS,Violate,Quantile_Score,Hit_Percentage);
Post.forecast = results;
disp(results);

end







