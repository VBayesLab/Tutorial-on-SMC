% This example uses SMC -likelihood annealing for samppling from GARCH
% model. See the details in the math notes supplied. 
% Also, see the details and notation in Section 5 of this paper: https://arxiv.org/pdf/1908.03097.pdf

clear all

% Training setting
mdl.T_anneal = 10000;    % Number of pre-specified annealing steps
mdl.M        = 5000;     % Number of particles in each annealing stage
mdl.K_lik    = 30;       % Number of Markov moves 
mdl.T        = 1000;     % size of the training time series 

% Prior setting: Inverse-Gamma(1,1) is used for the prior of w - the constant in the GARCH formula, 
% and uniform(0,1) prior is used for psi_1 and psi_2. 
mdl.prior.w_alpha = 1; mdl.prior.w_beta = 1;       

%% SP500 data
disp('SP500_weekly_Jan1988_Nov2018')
data       = load('Data/SP500_weekly_Jan1988_Nov2018.mat');
y_all      = data.y_demeaned';
y_train    = y_all(1:mdl.T);
mdl.sigma0 = var(y_train); %  initialize volatility in the GARCH formula with sample variance of the returns

% Run Likelihood annealing SMC for in-sample data
SMC_Post_SP500.LikAnneal = GARCH_LikAnneal(y_train,mdl);
save('Results_SMC_SP500')

figure
subplot(1,3,1)
[f,x] = ksdensity(SMC_Post_SP500.LikAnneal.w);   
plot(x,f,'-','LineWidth',3)
title('\omega')
set(gca,'FontSize',22)

subplot(1,3,2)
[f,x] = ksdensity(SMC_Post_SP500.LikAnneal.alpha);   
plot(x,f,'-','LineWidth',3)
title('\alpha')
set(gca,'FontSize',22)

subplot(1,3,3)
[f,x] = ksdensity(SMC_Post_SP500.LikAnneal.beta);   
plot(x,f,'-','LineWidth',3)
title('\beta')
set(gca,'FontSize',22)


% Forecast with data annealing
mdl.lik_anneal          = SMC_Post_SP500.LikAnneal;
mdl.K_data              = 30;
Post_SP500.DataAnneal = GARCH_DataAnneal(y_all,mdl);





plot(y_all(mdl.T+1:end))
hold on
plot(-Post_SP500.DataAnneal.volatility_forecast)
ylabel('Volatility forecast')
xlabel('Testing period')
legend('data','volatility forecast')








