function [llh,sigma2_end] = GARCH_llh(y,sigma0,alpha,beta,w)
% Calculate log-likelihood of GARCH with initial volatility sigma0, data y
% and parameters w, alpha and beta.
T      = length(y);
sigma2 = zeros(1,T);

% Initialization
sigma2(1) = sigma0;
for i = 2:T
    sigma2(i) = w + alpha*sigma2(i-1)+beta*y(i-1)^2;
end
llh = sum(-0.5*log(2*pi) - 0.5*log(sigma2) - 0.5*(y.^2)./sigma2);

sigma2_end = sigma2(end);

end

