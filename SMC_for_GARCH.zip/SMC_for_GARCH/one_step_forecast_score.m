function score = one_step_forecast_score(volatility_forecast,y_next,score)

alpha_sig = score.alpha;

if abs(y_next)>=norminv(1-alpha_sig/2)*sqrt(volatility_forecast)
    violate = 1;
else
    violate = 0;
end     
score.violate = score.violate + violate;
score.pps  = score.pps  + 0.5*log(2*pi)+0.5*log(volatility_forecast) + y_next^2/2/volatility_forecast;
score.crps = score.crps + utils_crps_normal(y_next,0,volatility_forecast);
VaR_t = norminv(alpha_sig)*sqrt(volatility_forecast);
score.qs = score.qs + (y_next-VaR_t)*(alpha_sig-utils_indicator_fun(y_next,VaR_t));
score.hit = score.hit + utils_indicator_fun(y_next,VaR_t);
end